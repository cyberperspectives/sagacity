CREATE DATABASE  IF NOT EXISTS `sagacity` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sagacity`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sagacity
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sw_name_match`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `sw_name_match` (
  `id` int(11) NOT NULL,
  `man_id` int(11) NOT NULL,
  `man_override` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `type` enum('ms-os','nix-os','net-os','ms','nix','checklist','multiple') NOT NULL DEFAULT 'multiple',
  `rgx` text NOT NULL,
  `name_match` varchar(15) DEFAULT NULL,
  `ver_match` varchar(15) DEFAULT NULL,
  `ver` varchar(15) DEFAULT NULL,
  `update_match` varchar(15) DEFAULT NULL,
  `is_os` tinyint(1) DEFAULT '0',
  `multiple` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `swnm_swmm_id` (`man_id`),
  CONSTRAINT `swnm_swmm_id` FOREIGN KEY (`man_id`) REFERENCES `sw_man_match` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sw_name_match`
--

INSERT IGNORE INTO `sw_name_match` (`man_id`, `man_override`, `name`, `type`, `rgx`, `name_match`, `ver_match`, `ver`, `update_match`, `is_os`, `multiple`) VALUES
(1,NULL,'AIX','checklist','AIX_([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(2,NULL,'HTTP Server','checklist','Apache_Server_([\\d\\.]+)|Apache_Site_([\\d\\.]+)',NULL,'1,2',NULL,NULL,0,0),
(3,NULL,'iPhone OS','checklist','Apple_iOS_([\\d]+)',NULL,'1',NULL,NULL,1,0),
(3,NULL,'MAC OS X','checklist','Apple_OS[X_]+([\\d\\.\\-]+)|MACOSX_([\\d\\.]+)',NULL,'1,2',NULL,NULL,1,0),
(4,NULL,'BIND','checklist','BIND_DNS',NULL,NULL,NULL,NULL,0,0),
(5,NULL,'IOS','checklist','Cisco_IAVAs',NULL,NULL,NULL,NULL,1,0),
(6,NULL,'Database Server','checklist','Database_\\-_Oracle_([\\d\\.]+)g|Oracle_Database_([\\d\\.]+)[a-z]',NULL,'1,2',NULL,NULL,0,0),
(6,NULL,'Linux','checklist','Oracle_Linux_([\\d]+)',NULL,'1',NULL,NULL,1,0),
(6,NULL,'HTTP Server','checklist','Oracle_HTTP_Server_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(6,NULL,'WebLogic Server','checklist','Oracle_WebLogic_Server_([\\d]+)[a-z]',NULL,'1',NULL,NULL,0,0),
(7,NULL,'Exchange Server','checklist','Exchange_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(8,NULL,'Chrome','checklist','Google_Chrome_v([\\d]+)|Google_Chrome',NULL,'1',NULL,NULL,0,0),
(8,NULL,'Android','checklist','Android_([\\d\\.]+)|Android_OS_([\\d\\.]+)',NULL,'1,2',NULL,NULL,1,0),
(9,NULL,'VirusScan Enterprise','checklist','McAfee_VirusScan([\\d])|McAfee_VirusScan',NULL,'1',NULL,NULL,0,0),
(9,NULL,'McAfee Agent','checklist','HBSS_McAfee_Agent ',NULL,NULL,NULL,NULL,0,1),
(9,NULL,'Host Intrusion Prevention Server','checklist','HBSS_HIPS',NULL,NULL,NULL,NULL,0,0),
(9,NULL,'ePolicy Orchestrator','checklist','HBSS_ePO_([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(9,NULL,'Agent','checklist','HBSS_McAfee_Agent',NULL,NULL,NULL,NULL,0,1),
(9,NULL,'Host Intrusion Prevention','checklist','HBSS_HIP_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(9,NULL,'Policy Auditor','checklist','HBSS_PolicyAuditor',NULL,NULL,NULL,NULL,0,0),
(9,NULL,'Remote Desktop 32','checklist','HBSS_\\-_Remote_Console',NULL,NULL,NULL,NULL,0,0),
(9,NULL,'Rogue System Detection Sensor','checklist','HBSS_Rogue_Sensor',NULL,NULL,NULL,NULL,0,0),
(10,NULL,'HP-UX','checklist','HPUX_([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(11,NULL,'IE','checklist','IE_?([\d]+)|IE_Version_([\d]+)',NULL,'1,2',NULL,NULL,0,1),
(11,NULL,'Internet Explorer','checklist','IE_?([\\d]+)|IE_Version_([\\d]+)',NULL,'1,2',NULL,NULL,0,0),
(12,NULL,'IIS','checklist','IIS_?([\\d]+)',NULL,'1',NULL,NULL,0,0),
(13,NULL,'JRE','checklist','JRE_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Access','checklist','Access_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Excel','checklist','Excel_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Groove','checklist','Groove_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'InfoPath','checklist','InfoPath_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Lync','checklist','Lync_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Office','checklist','Office_System_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'OneNote','checklist','OneNote_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Outlook','checklist','Outlook_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'PowerPoint','checklist','PowerPoint_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Project','checklist','Project_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Publisher','checklist','Publisher_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Visio','checklist','Visio_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(14,NULL,'Word','checklist','Word_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(15,NULL,'SharePoint Server','checklist','Sharepoint_([\\d]+)',NULL,'1',NULL,NULL,0,0),
(15,NULL,'SharePoint Designer','checklist','SharepointDesign_([\\d]+)|Sharepoint_Designer_([\\d]+)',NULL,'1,2',NULL,NULL,0,0),
(16,NULL,'SQL Server','checklist','SQL_Server_9|SQL_Server_Version_9',NULL,NULL,'2005',NULL,0,0),
(16,NULL,'SQL Server','checklist','MSSQL_([\\d]+)|SQL_Server_([\\d]+)',NULL,'1,2',NULL,NULL,0,0),
(17,NULL,'Firefox','checklist','Firefox',NULL,NULL,NULL,NULL,0,0),
(18,NULL,'Enterprise Linux','checklist','RHEL_([\\d]+)',NULL,'1',NULL,NULL,1,1),
(18,'CentOS','CentOS','checklist','RHEL_([\\d]+)',NULL,'1',NULL,NULL,1,1),
(19,NULL,'Solaris','checklist','Solaris_([\\d]+)_SPARC',NULL,'1',NULL,NULL,1,0),
(19,NULL,'Solaris','checklist','Solaris_([\\d]+)_X86',NULL,'1',NULL,NULL,1,0),
(20,NULL,'SuSE Linux','checklist','SuSe_zLinu[sx]',NULL,NULL,NULL,NULL,1,1),
(20,NULL,'OpenSUSE','checklist','SuSe_zLinu[sx]',NULL,NULL,NULL,NULL,1,1),
(21,NULL,'AntiVirus','checklist','Symantec_AntiVirus',NULL,NULL,NULL,NULL,0,0),
(21,NULL,'Endpoint Protection','checklist','Symantec_?Endpoint_?Protection_([\\d_\\.]+)',NULL,'1',NULL,NULL,0,0),
(22,NULL,'ESX','checklist','VMWare_[ESXi]+_([\\d\\.]+)',NULL,'1',NULL,NULL,1,1),
(22,NULL,'ESXi','checklist','VMWare_[ESXi]+_([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(22,NULL,'vCenter Server','checklist','VMWare_vCenter_Server_([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(23,NULL,'Windows','checklist','Windows_(XP|Vista|[1780]+)_[^M]|Windows_Firewall','1',NULL,NULL,NULL,1,1),
(23,NULL,'Windows 2003 Server','checklist','Windows_2003|AD_STIG_2003|Windows_Firewall',NULL,NULL,NULL,NULL,1,1),
(23,NULL,'Windows Server','checklist','Windows_(2\\d{3})_(R2)?_?MS|AD_STIG_(\\d{4})|Windows_Firewall','1,3','2',NULL,NULL,1,1),
(24,NULL,'.NET Framework','checklist','MS_Dot_Net_Framework',NULL,NULL,NULL,NULL,0,0),
(25,NULL,'ISA Server','checklist','ISA_Server_([\\d]+)|ISA_Server',NULL,'1',NULL,NULL,0,0),
(26,NULL,'Windows 2003 Server','checklist','AD_Forest|AD_Domain|Ac[ti]+ve_Directory',NULL,NULL,NULL,NULL,1,1),
(26,NULL,'Windows Server 2003','checklist','AD_Forest|AD_Domain|Ac[ti]+ve_Directory',NULL,NULL,NULL,NULL,1,1),
(26,NULL,'Windows Server 2008','checklist','AD_Forest|AD_Domain|Ac[ti]+ve_Directory',NULL,NULL,NULL,NULL,1,1),
(26,NULL,'Windows Server 2012','checklist','AD_Forest|AD_Domain|Ac[ti]+ve_Directory',NULL,NULL,NULL,NULL,1,1),
(27,'MySQL','MySQL','checklist','Database_Generic_SRG',NULL,NULL,NULL,NULL,0,1),
(27,'Oracle','MySQL','checklist','Database_Generic_SRG',NULL,NULL,NULL,NULL,0,1),
(27,'PostgreSQL','PostgreSQL','checklist','Database_Generic_SRG',NULL,NULL,NULL,NULL,0,1),
(27,'MariaDB','MariaDB','checklist','Database_Generic_SRG',NULL,NULL,NULL,NULL,0,1),
(28,NULL,'Adaptive Security Appliance Software','net-os','Adaptive Security Appliance Software[^\\d]+([\\d\\.\\(\\)]+)',NULL,'1',NULL,NULL,0,0),
(28,NULL,'IOS','net-os','Cisco IOS ([^\\s]+)*',NULL,'1',NULL,NULL,1,0),
(29,NULL,'FreeBSD','nix-os','FreeBSD ([\\d\\.]+)*',NULL,'1',NULL,NULL,1,0),
(30,NULL,'Enterprise Linux','nix-os','Red ?Hat Enterprise Linux[^\\d]+([\\d\\.]+)',NULL,'1,2,3',NULL,NULL,1,0),
(30,NULL,'Enterprise Linux','nix-os','CentOS[^\\d]+([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(30,NULL,'Enterprise Linux','nix-os','Linux Kernel [\\d\\.\\-]+e[ls]([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(31,NULL,'SuSE Linux','nix-os','SuSE ?([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(32,NULL,'Linux Kernel','nix-os','Linux Kernel ([\\d\\.]+)\\-?([\\d]+)?',NULL,'1',NULL,2,1,0),
(33,NULL,'Windows Server','ms-os','Windows Server (2[\\d]{3}) (R2) ?(Datacenter|Enterprise|Standard) ?(Service Pack [\\d]+)*|Windows Server (2[\\d]{3}) ?(Datacenter|Enterprise|Standard) ?(Service Pack [\\d]+)*','1,5','2',NULL,'4,7',1,1),
(33,NULL,'Windows 2003 Server','ms-os','Windows 2003 Server.*(Service Pack [\\d]+)|Windows Server 2003.*(Service Pack [\\d]+)|Windows Server 2003',NULL,NULL,NULL,'1',1,1),
(33,NULL,'Windows','ms-os','Windows (XP|Vista|[^2 ]{1,2}) ?(Professional|Enterprise)* ?(Service Pack [\\d]+)*','1',NULL,NULL,'3',1,0),
(34,NULL,'Solaris','nix-os','Solaris ([\\d\\.]+)',NULL,'1',NULL,NULL,1,0),
(35,'Google','Chrome','ms','Google Chrome \\[version ([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(35,NULL,'IIS','ms','IIS ([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(35,'Oracle','JRE','ms','J2SE[^\\d]+([\\d]+)[^U]+Update ([\\d]+)|Java[^\\d]+([\\d]+) Update ([\\d]+)',NULL,'1,3',NULL,'2,4',0,1),
(35,'McAfee','Agent','ms','McAfee Agent[^\\[]+\\[version ([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(35,'McAfee','VirusScan Enterprise','ms','McAfee VirusScan Enterprise[^\\[]+\\[version ([\\d\\.]{1,3})',NULL,'1',NULL,NULL,0,0),
(35,NULL,'.NET Framework','ms','Microsoft \\.NET Framework ([\\d\\.]+) ?(Service Pack [\\d]+|SP[\\d]+)*[^\\[]+\\[version ([\\d\\.]{1,3})',NULL,'1',NULL,'2',0,0),
(35,NULL,'.NET Framework','ms','Microsoft \\.NET Compact Framework ([\\d\\.]+) (Service Pack [\\d]+|SP[\\d]+)*[^\\[]+\\[version ([\\d\\.]{1,3})',NULL,'1',NULL,'2',0,0),
(35,NULL,'.NET Framework','ms','Microsoft \\.NET Framework[^\\d\\[]+\\[version (([\\d\\.]{1,3})[\\d\\.]+)',NULL,'2',NULL,NULL,0,0),
(35,NULL,'Access','ms','Access[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Excel','ms','Excel[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Groove','ms','Groove[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'InfoPath','ms','InfoPath[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Lync','ms','Lync[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Outlook','ms','Outlook[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'OneNote','ms','OneNote[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'PowerPoint','ms','PowerPoint[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Publisher','ms','Publisher[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Project','ms','Project[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Visio','ms','Visio[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Word','ms','Word[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'Office','ms','Professional[^\\d]+([\\d]+).*(Service Pack [\\d]+)*',NULL,'1',NULL,'2',0,0),
(35,NULL,'SQL Server','ms','SQL Server ([\\d]+) (R2)? ?(SP\\d)?',NULL,'1',NULL,'2,3',0,0),
(35,'Mozilla','Firefox','ms','Mozilla Firefox[^\\[]+\\[version ([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(35,'Symantec','Antivirus','ms','Antivirus[^\\[]+\\[version ([\\d\\.]{1,4})',NULL,'1',NULL,NULL,0,0),
(35,'Symantec','Endpoint Protection Manager','ms','Endpoint Protection Manager[^\\[]+\\[version ([\\d\\.]{1,4})',NULL,'1',NULL,NULL,0,0),
(35,'Symantec','Endpoint Protection','ms','Endpoint Protection[^\\[]+\\[version ([\\d\\.]{1,4})',NULL,'1',NULL,NULL,0,0),
(35,'VMWare','vCenter Server','ms','vCenter Server[^\\[]+\\[version ([\\d\\.]{1,4})',NULL,'1',NULL,NULL,0,0),
(35,NULL,'Internet Explorer','ms','Internet Explorer ([\\d\\.]+)',NULL,'1',NULL,NULL,0,1),
(36,NULL,'HTTP Server','nix','(apache\\d?|httpd)\\-([\\d\\.]+)',NULL,'2',NULL,NULL,0,0),
(37,NULL,'BIND','nix','([^yp]+)bind\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(38,NULL,'Firefox','nix','firefox\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(39,NULL,'JRE','nix','java\\-\\d[\\._](\\d)[\\._]\\d',NULL,'1',NULL,NULL,0,0),
(39,NULL,'JRE','nix','jre\\-[\\d]\\.(\\d)\\.\\d_([\\d]+)|jdk\\-[\\d]\\.(\\d)\\.\\d_([\\d]+)',NULL,'1,3',NULL,'2,4',0,0),
(40,NULL,'MySQL','nix','mysql\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,1),
(40,'Oracle','MySQL','nix','mysql\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(41,NULL,'OpenLDAP','nix','openldap\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(42,NULL,'Postfix','nix','postfix\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(43,NULL,'Procmail','nix','procmail\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(44,NULL,'Sendmail','nix','sendmail\\-([\\d\\.]+)',NULL,'1',NULL,NULL,0,0),
(35,NULL,'IE','ms','Internet Explorer ([\\d\\.]+)',NULL,'1',NULL,NULL,0,1),
(45,NULL,'Acrobat Reader DC','checklist','Adobe_Acrobat_Reader_DC',NULL,1,NULL,NULL,0,0),
(45,NULL,'Coldfusion','checklist','Adobe_Coldfusion',NULL,1,NULL,NULL,0,0),
(46,NULL,'Postgresql','checklist','Postgres_Advanced_Server',NULL,NULL,NULL,NULL,0,0),
(47,NULL,'Skype for Business','checklist','Skype_for_Business_([\d]+)',NULL,'1',NULL,NULL,0,0)
;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
