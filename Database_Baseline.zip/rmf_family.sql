CREATE DATABASE  IF NOT EXISTS `rmf` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `rmf`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rmf
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `family`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `family` (
  `abbr` varchar(4) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`abbr`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family`
--

REPLACE INTO `family` (`abbr`, `name`) VALUES ('AC','Access Control Policy And Procedures'),('AT','Security Awareness And Training Policy And Procedures'),('AU','Audit And Accountability Policy And Procedures'),('CA','Security Assessment And Authorization Policy And Procedures'),('CM','Configuration Management Policy And Procedures'),('CP','Contingency Planning Policy And Procedures'),('IA','Identification And Authentication Policy And Procedures'),('IR','Incident Response Policy And Procedures'),('MA','System Maintenance Policy And Procedures'),('MP','Media Protection Policy And Procedures'),('PE','Physical And Environmental Protection Policy And Procedures'),('PL','Security Planning Policy And Procedures'),('PM','Information Security Program Plan'),('PS','Personnel Security Policy And Procedures'),('RA','Risk Assessment Policy And Procedures'),('SA','System And Services Acquisition Policy And Procedures'),('SC','System And Communications Protection Policy And Procedures'),('SI','System And Information Integrity Policy And Procedures');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
