CREATE DATABASE  IF NOT EXISTS `sagacity` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sagacity`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: sagacity
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sw_man_match`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `sw_man_match` (
  `id` int(11) NOT NULL,
  `man` varchar(45) DEFAULT NULL,
  `type` enum('ms-os','nix-os','net-os','ms','nix','checklist','multiple') NOT NULL DEFAULT 'multiple',
  `rgx` text NOT NULL,
  PRIMARY KEY (`id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sw_man_match`
--

INSERT IGNORE INTO `sw_man_match` (`id`, `man`, `type`, `rgx`) VALUES
(1,'IBM','checklist','AIX_[\\d\\.]+'),
(2,'Apache','checklist','Apache_Server_[\\d\\.]+|Apache_Site_[\\d\\.]+'),
(3,'Apple','checklist','Apple_iOS_[\\d]+|Apple_OS[X_]+[\\d\\.\\-]+|MACOSX_[\\d\\.]+'),
(4,'ISC','checklist','BIND_DNS'),
(5,'Cisco','checklist','Cisco_CSS|Cisco_IAVA'),
(6,'Oracle','checklist','Oracle_[\\d\\.]+[a-z]|Oracle_Database_[\\d\\.]+[a-z]|Oracle_Linux_[\\d]+|Oracle_HTTP_Server|Oracle_WebLogic_Server'),
(7,'Microsoft','checklist','Exchange_[\\d]+'),
(8,'Google','checklist','Google_Chrome|Android_[\\d\\.]+|Android_OS_[\\d\\.]+'),
(9,'McAfee','checklist','HBSS|VirusScan'),
(10,'HP','checklist','HPUX'),
(11,'Microsoft','checklist','IE_?[\\d]+|IE_Version_[\\d]+'),
(12,'Microsoft','checklist','IIS_?[\\d\\.]+'),
(13,'Oracle','checklist','JRE_[\\d]+'),
(14,'Microsoft','checklist','Access_[\\d]+|Excel_[\\d]+|Groove_[\\d]+|InfoPath_[\\d]+|Lync_[\\d]+|OneNote_[\\d]+|Outlook_[\\d]+|PowerPoint_[\\d]+|Project_[\\d]+|Publisher_[\\d]+|Visio_[\\d]+|Word_[\\d]+|Office_System_[\\d]+'),
(15,'Microsoft','checklist','SharePoint_[\\d]+|SharePointDesign_[\\d]+|SharePoint_Designer_[\\d]+'),
(16,'Microsoft','checklist','SQL_Server_[\\d]+|MSSQL_[\\d]+|SQL_Server_Version_[\\d]+'),
(17,'Mozilla','checklist','Firefox'),
(18,'RedHat','checklist','RHEL_[\\d]+'),
(19,'Oracle','checklist','Solaris_[\\d]+_SPARC|Solaris_[\\d]+_X86'),
(20,'Novell','checklist','SuSe_zLinu[sx]'),
(21,'Symantec','checklist','Symantec_Antivirus|Symantec_?Endpoint_?Protection_[\\d\\._]+'),
(22,'VMware','checklist','VMWare_[ESXi]+_[\\d\\.]+|VMWare_vCenter_Server_[\\d\\.]+'),
(23,'Microsoft','checklist','Windows_[\\d]+_R2|Windows_([\\d]+|XP|Vista|Firewall)|AD_STIG_200[38]'),
(24,'Microsoft','checklist','MS_Dot_Net_Framework'),
(25,'Microsoft','checklist','Microsoft_ISA_Server'),
(26,'Microsoft','checklist','Ac[it]+ve_Directory|AD_Domain|AD_Forest'),
(27,'DB','checklist','Database_Generic_SRG'),
(28,'Cisco','net-os','Cisco'),
(29,'FreeBSD','nix-os','FreeBSD'),
(30,'RedHat','nix-os','Red ?Hat Enterprise Linux[^\\d]+[\\d\\.]+|CentOS[^\\d]+[\\d\\.]+|Linux Kernel [\\d\\.\\-]+el[\\d]+'),
(31,'Novell','nix-os','SuSE ?[\\d\\.]+'),
(32,'Linux','nix-os','Linux Kernel [\\d\\.]+'),
(33,'Microsoft','ms-os','Windows'),
(34,'Oracle','nix-os','Solaris [\\d]+'),
(35,'Microsoft','ms','\\[version [\\d\\.]+'),
(36,'Apache','nix','(apache\\d?|httpd)\\-[\\d\\.]+'),
(37,'ISC','nix','bind\\-[\\d\\.]+'),
(38,'Mozilla','nix','firefox\\-[\\d\\.]+'),
(39,'Oracle','nix','java\\-[\\d\\._]+|jre\\-[\\d\\._]+|jdk\\-[\\d\\._]+'),
(40,'MySQL','nix','mysql\\-([\\d\\.]+)'),
(41,'OpenLDAP','nix','openldap\\-([\\d\\.]+)'),
(42,'Postfix','nix','postfix\\-([\\d\\.]+)'),
(43,'Procmail','nix','procmail\\-([\\d\\.]+)'),
(44,'Sendmail','nix','sendmail\\-([\\d\\.]+)'),
(45,'Adobe','checklist','Adobe_Acrobat_Reader|Adobe_Coldfuion'),
(46,'Postgresql','checklist','Postgres_Advanced_Server'),
(47,'Microsoft','checklist','Skype_for_Business')
;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
