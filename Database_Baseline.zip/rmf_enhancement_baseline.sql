CREATE DATABASE  IF NOT EXISTS `rmf` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `rmf`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rmf
-- ------------------------------------------------------
-- Server version	5.6.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `enhancement_baseline`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `enhancement_baseline` (
  `impact` enum('low','moderate','high') NOT NULL,
  `control_id` varchar(6) NOT NULL,
  `enh_id` varchar(4) NOT NULL,
  PRIMARY KEY (`impact`,`control_id`,`enh_id`),
  KEY `rmf_enh_baseline_enh_id_idx` (`enh_id`),
  KEY `rmf_enh_baseline_control_id_idx` (`control_id`),
  CONSTRAINT `rmf_enh_baseline_control_id` FOREIGN KEY (`control_id`) REFERENCES `controls` (`control_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `rmf_enh_baseline_enh_id` FOREIGN KEY (`enh_id`) REFERENCES `control_enh` (`enh_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enhancement_baseline`
--

REPLACE INTO `enhancement_baseline` (`impact`, `control_id`, `enh_id`) VALUES ('low','IA-2','1'),('low','IA-5','1'),('low','IA-8','1'),('moderate','AC-11','1'),('moderate','AC-17','1'),('moderate','AC-18','1'),('moderate','AC-2','1'),('moderate','AC-20','1'),('moderate','AC-6','1'),('moderate','AU-3','1'),('moderate','AU-6','1'),('moderate','AU-7','1'),('moderate','AU-8','1'),('moderate','CA-2','1'),('moderate','CA-7','1'),('moderate','CM-2','1'),('moderate','CM-7','1'),('moderate','CM-8','1'),('moderate','CP-2','1'),('moderate','CP-4','1'),('moderate','CP-6','1'),('moderate','CP-7','1'),('moderate','CP-8','1'),('moderate','CP-9','1'),('moderate','IA-2','1'),('moderate','IA-5','1'),('moderate','IA-8','1'),('moderate','IR-4','1'),('moderate','IR-6','1'),('moderate','IR-7','1'),('moderate','MA-3','1'),('moderate','MP-7','1'),('moderate','PE-6','1'),('moderate','PL-4','1'),('moderate','RA-5','1'),('moderate','SA-4','1'),('moderate','SC-8','1'),('moderate','SI-3','1'),('moderate','SI-7','1'),('moderate','SI-8','1'),('high','AC-11','1'),('high','AC-17','1'),('high','AC-18','1'),('high','AC-2','1'),('high','AC-20','1'),('high','AC-6','1'),('high','AU-12','1'),('high','AU-3','1'),('high','AU-5','1'),('high','AU-6','1'),('high','AU-7','1'),('high','AU-8','1'),('high','CA-2','1'),('high','CA-7','1'),('high','CM-2','1'),('high','CM-3','1'),('high','CM-4','1'),('high','CM-5','1'),('high','CM-6','1'),('high','CM-7','1'),('high','CM-8','1'),('high','CP-2','1'),('high','CP-3','1'),('high','CP-4','1'),('high','CP-6','1'),('high','CP-7','1'),('high','CP-8','1'),('high','CP-9','1'),('high','IA-2','1'),('high','IA-5','1'),('high','IA-8','1'),('high','IR-2','1'),('high','IR-4','1'),('high','IR-5','1'),('high','IR-6','1'),('high','IR-7','1'),('high','MA-3','1'),('high','MA-5','1'),('high','MP-6','1'),('high','MP-7','1'),('high','PE-11','1'),('high','PE-13','1'),('high','PE-15','1'),('high','PE-3','1'),('high','PE-6','1'),('high','PE-8','1'),('high','PL-4','1'),('high','RA-5','1'),('high','SA-4','1'),('high','SC-12','1'),('high','SC-8','1'),('high','SI-2','1'),('high','SI-3','1'),('high','SI-5','1'),('high','SI-7','1'),('high','SI-8','1'),('low','SA-4','10'),('moderate','AC-6','10'),('moderate','SA-4','10'),('high','AC-6','10'),('high','SA-4','10'),('low','IA-5','11'),('moderate','IA-2','11'),('moderate','IA-5','11'),('high','AC-2','11'),('high','IA-2','11'),('high','IA-5','11'),('low','IA-2','12'),('moderate','IA-2','12'),('high','AC-2','12'),('high','IA-2','12'),('high','AC-2','13'),('high','SI-7','14'),('high','SC-7','18'),('low','IA-8','2'),('moderate','AC-17','2'),('moderate','AC-2','2'),('moderate','AC-20','2'),('moderate','AC-6','2'),('moderate','AT-2','2'),('moderate','CM-3','2'),('moderate','CM-7','2'),('moderate','CP-10','2'),('moderate','CP-7','2'),('moderate','CP-8','2'),('moderate','IA-2','2'),('moderate','IA-5','2'),('moderate','IA-8','2'),('moderate','IR-3','2'),('moderate','MA-3','2'),('moderate','MA-4','2'),('moderate','RA-5','2'),('moderate','SA-4','2'),('moderate','SA-9','2'),('moderate','SI-2','2'),('moderate','SI-3','2'),('moderate','SI-4','2'),('moderate','SI-8','2'),('high','AC-17','2'),('high','AC-2','2'),('high','AC-20','2'),('high','AC-6','2'),('high','AT-2','2'),('high','AU-3','2'),('high','AU-5','2'),('high','AU-9','2'),('high','CA-2','2'),('high','CM-2','2'),('high','CM-3','2'),('high','CM-5','2'),('high','CM-6','2'),('high','CM-7','2'),('high','CM-8','2'),('high','CP-10','2'),('high','CP-2','2'),('high','CP-4','2'),('high','CP-6','2'),('high','CP-7','2'),('high','CP-8','2'),('high','CP-9','2'),('high','IA-2','2'),('high','IA-5','2'),('high','IA-8','2'),('high','IR-2','2'),('high','IR-3','2'),('high','MA-2','2'),('high','MA-3','2'),('high','MA-4','2'),('high','MP-6','2'),('high','PE-13','2'),('high','PS-4','2'),('high','RA-5','2'),('high','SA-4','2'),('high','SA-9','2'),('high','SI-2','2'),('high','SI-3','2'),('high','SI-4','2'),('high','SI-7','2'),('high','SI-8','2'),('high','SC-7','21'),('low','IA-8','3'),('moderate','AC-17','3'),('moderate','AC-2','3'),('moderate','AU-2','3'),('moderate','AU-6','3'),('moderate','CM-2','3'),('moderate','CM-8','3'),('moderate','CP-2','3'),('moderate','CP-6','3'),('moderate','CP-7','3'),('moderate','IA-2','3'),('moderate','IA-5','3'),('moderate','IA-8','3'),('moderate','PE-13','3'),('moderate','PL-2','3'),('moderate','SC-7','3'),('high','AC-17','3'),('high','AC-2','3'),('high','AC-6','3'),('high','AU-12','3'),('high','AU-2','3'),('high','AU-6','3'),('high','AU-9','3'),('high','CM-2','3'),('high','CM-5','3'),('high','CM-8','3'),('high','CP-2','3'),('high','CP-6','3'),('high','CP-7','3'),('high','CP-8','3'),('high','CP-9','3'),('high','IA-2','3'),('high','IA-5','3'),('high','IA-8','3'),('high','MA-3','3'),('high','MA-4','3'),('high','MP-6','3'),('high','PE-13','3'),('high','PL-2','3'),('high','SC-7','3'),('low','IA-8','4'),('moderate','AC-17','4'),('moderate','AC-2','4'),('moderate','AU-9','4'),('moderate','CM-7','4'),('moderate','IA-8','4'),('moderate','MP-5','4'),('moderate','SC-7','4'),('moderate','SI-4','4'),('high','AC-17','4'),('high','AC-18','4'),('high','AC-2','4'),('high','AU-9','4'),('high','CM-8','4'),('high','CP-10','4'),('high','CP-2','4'),('high','CP-7','4'),('high','CP-8','4'),('high','IA-2','4'),('high','IA-8','4'),('high','IR-4','4'),('high','MP-5','4'),('high','PE-6','4'),('high','RA-5','4'),('high','SC-7','4'),('high','SI-4','4'),('moderate','AC-19','5'),('moderate','AC-6','5'),('moderate','CA-3','5'),('moderate','CM-8','5'),('moderate','RA-5','5'),('moderate','SC-7','5'),('moderate','SI-4','5'),('high','AC-18','5'),('high','AC-19','5'),('high','AC-2','5'),('high','AC-6','5'),('high','AU-6','5'),('high','CA-3','5'),('high','CM-7','5'),('high','CM-8','5'),('high','CP-2','5'),('high','CP-9','5'),('high','RA-5','5'),('high','SC-7','5'),('high','SI-4','5'),('high','SI-7','5'),('high','AU-6','6'),('moderate','CM-2','7'),('moderate','SC-7','7'),('moderate','SI-7','7'),('high','CM-2','7'),('high','SC-7','7'),('high','SI-7','7'),('moderate','CP-2','8'),('moderate','IA-2','8'),('high','CP-2','8'),('high','IA-2','8'),('high','SC-7','8'),('moderate','AC-6','9'),('moderate','SA-4','9'),('high','AC-6','9'),('high','IA-2','9'),('high','SA-4','9');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed
