use sagacity;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: mysql.local    Database: sagacity
-- ------------------------------------------------------
-- Server version	5.7.20-log

SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0;

--
-- Temporary view structure for view `get_ports`
--

DROP TABLE IF EXISTS `get_ports`;
DROP VIEW IF EXISTS `get_ports`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_ports` AS SELECT 
 1 AS `int_id`,
 1 AS `id`,
 1 AS `port`,
 1 AS `proto`,
 1 AS `listening`,
 1 AS `name`,
 1 AS `banner`,
 1 AS `notes`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ste_target_list`
--

DROP TABLE IF EXISTS `ste_target_list`;
DROP VIEW IF EXISTS `ste_target_list`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `ste_target_list` AS SELECT 
 1 AS `ste_id`,
 1 AS `system_id`,
 1 AS `site_id`,
 1 AS `eval_start`,
 1 AS `eval_end`,
 1 AS `system_name`,
 1 AS `mac`,
 1 AS `classification`,
 1 AS `site_name`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_cat_findings`
--

DROP TABLE IF EXISTS `get_cat_findings`;
DROP VIEW IF EXISTS `get_cat_findings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_cat_findings` AS SELECT 
 1 AS `chk_id`,
 1 AS `chk_icon`,
 1 AS `chk_type`,
 1 AS `stig_id`,
 1 AS `check_contents`,
 1 AS `vms_id`,
 1 AS `short_title`,
 1 AS `tgt_id`,
 1 AS `tgt_name`,
 1 AS `cat_id`,
 1 AS `pdi_id`,
 1 AS `finding_cat`,
 1 AS `notes`,
 1 AS `cat`,
 1 AS `finding_status`,
 1 AS `finding_ia_controls`,
 1 AS `ia_controls`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_orphan_findings`
--

DROP TABLE IF EXISTS `get_orphan_findings`;
DROP VIEW IF EXISTS `get_orphan_findings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_orphan_findings` AS SELECT 
 1 AS `chk_id`,
 1 AS `chk_icon`,
 1 AS `chk_type`,
 1 AS `stig_id`,
 1 AS `check_contents`,
 1 AS `vms_id`,
 1 AS `short_title`,
 1 AS `tgt_id`,
 1 AS `tgt_name`,
 1 AS `cat_id`,
 1 AS `finding_status`,
 1 AS `pdi_id`,
 1 AS `notes`,
 1 AS `finding_cat`,
 1 AS `cat`,
 1 AS `finding_ia_controls`,
 1 AS `ia_controls`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_cat_pdi_count`
--

DROP TABLE IF EXISTS `get_cat_pdi_count`;
DROP VIEW IF EXISTS `get_cat_pdi_count`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_cat_pdi_count` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `pdi_count`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_target_pdi_count`
--

DROP TABLE IF EXISTS `get_target_pdi_count`;
DROP VIEW IF EXISTS `get_target_pdi_count`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_target_pdi_count` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `pdi_count`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `target_view`
--

DROP TABLE IF EXISTS `target_view`;
DROP VIEW IF EXISTS `target_view`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `target_view` AS SELECT 
 1 AS `ste_id`,
 1 AS `cat_name`,
 1 AS `id`,
 1 AS `name`,
 1 AS `os`,
 1 AS `location`,
 1 AS `notes`,
 1 AS `auto_status`,
 1 AS `man_status`,
 1 AS `data_status`,
 1 AS `fp_cat1_status`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_cat_finding_count`
--

DROP TABLE IF EXISTS `get_cat_finding_count`;
DROP VIEW IF EXISTS `get_cat_finding_count`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_cat_finding_count` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `cat_id`,
 1 AS `severity`,
 1 AS `finding_count`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `get_target_finding_count`
--

DROP TABLE IF EXISTS `get_target_finding_count`;
DROP VIEW IF EXISTS `get_target_finding_count`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `get_target_finding_count` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `cat_id`,
 1 AS `severity`,
 1 AS `finding_count`;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `pdi`
--

DROP TABLE IF EXISTS `pdi`;
DROP VIEW IF EXISTS `pdi`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE VIEW `pdi` AS SELECT 
 1 AS `pdi_id`,
 1 AS `STIG_ID`,
 1 AS `VMS_ID`,
 1 AS `CAT`,
 1 AS `IA_Controls`,
 1 AS `Notes`,
 1 AS `SCAP_Rule`,
 1 AS `Nessus_ID`;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `get_ports`
--

DROP VIEW IF EXISTS `get_ports`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_ports` AS
    (SELECT 
        `ppsl`.`int_id` AS `int_id`,
        `pps`.`id` AS `id`,
        `pps`.`port` AS `port`,
        `pps`.`proto` AS `proto`,
        `ppsl`.`listening` AS `listening`,
        IF((`ppsl`.`name` <> `pps`.`IANA_Name`),
            `ppsl`.`name`,
            `pps`.`IANA_Name`) AS `name`,
        IF((`ppsl`.`banner` <> `pps`.`banner`),
            `ppsl`.`banner`,
            `pps`.`banner`) AS `banner`,
        IF((`ppsl`.`notes` IS NOT NULL),
            `ppsl`.`notes`,
            `pps`.`notes`) AS `notes`
    FROM
        (`ports_proto_services` `pps`
        LEFT JOIN `pps_list` `ppsl` ON ((`ppsl`.`pps_id` = `pps`.`id`)))
    WHERE
        (`pps`.`id` IN (SELECT 
                `pps_list`.`pps_id`
            FROM
                `pps_list`
            WHERE
                (`pps_list`.`int_id` = `pps_list`.`int_id`))
            AND (`ppsl`.`int_id` = `ppsl`.`int_id`)));
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `ste_target_list`
--

DROP VIEW IF EXISTS `ste_target_list`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `ste_target_list` AS
    (SELECT 
        `ste`.`id` AS `ste_id`,
        `ste`.`system_id` AS `system_id`,
        `ste`.`site_id` AS `site_id`,
        `ste`.`eval_start` AS `eval_start`,
        `ste`.`eval_end` AS `eval_end`,
        `sys`.`name` AS `system_name`,
        `sys`.`mac` AS `mac`,
        `sys`.`classification` AS `classification`,
        `s`.`name` AS `site_name`
    FROM
        ((`ste`
        LEFT JOIN `system` `sys` ON ((`ste`.`system_id` = `sys`.`id`)))
        LEFT JOIN `sites` `s` ON ((`ste`.`site_id` = `s`.`id`))));
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `get_cat_findings`
--

DROP VIEW IF EXISTS `get_cat_findings`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_cat_findings` AS
    SELECT 
        `chk`.`id` AS `chk_id`,
        `chk`.`icon` AS `chk_icon`,
        `chk`.`type` AS `chk_type`,
        `s`.`stig_id` AS `stig_id`,
        `pcl`.`check_contents` AS `check_contents`,
        `v`.`vms_id` AS `vms_id`,
        `pdi`.`short_title` AS `short_title`,
        `tgt`.`id` AS `tgt_id`,
        `tgt`.`name` AS `tgt_name`,
        `tgt`.`cat_id` AS `cat_id`,
        `pdi`.`id` AS `pdi_id`,
        `f`.`cat` AS `finding_cat`,
        `f`.`notes` AS `notes`,
        `pdi`.`cat` AS `cat`,
        IF(ISNULL(`f`.`findings_status_id`),
            'Not Reviewed',
            `fs`.`status`) AS `finding_status`,
        (SELECT 
                GROUP_CONCAT(`fc`.`ia_control`
                        SEPARATOR ' ')
            FROM
                `finding_controls` `fc`
            WHERE
                (`fc`.`finding_id` = `f`.`id`)) AS `finding_ia_controls`,
        (SELECT 
                GROUP_CONCAT(DISTINCT CONCAT(`ia`.`type`, '-', `ia`.`type_id`)
                        SEPARATOR ' ')
            FROM
                `ia_controls` `ia`
            WHERE
                (`ia`.`pdi_id` = `pcl`.`pdi_id`)) AS `ia_controls`
    FROM
        ((((((((`checklist` `chk`
        JOIN `target_checklist` `tc` ON ((`tc`.`chk_id` = `chk`.`id`)))
        JOIN `target` `tgt` ON ((`tgt`.`id` = `tc`.`tgt_id`)))
        LEFT JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `chk`.`id`)))
        LEFT JOIN `findings` `f` ON (((`f`.`pdi_id` = `pcl`.`pdi_id`)
            AND (`f`.`tgt_id` = `tgt`.`id`))))
        LEFT JOIN `findings_status` `fs` ON ((`fs`.`id` = `f`.`findings_status_id`)))
        LEFT JOIN `stigs` `s` ON ((`s`.`pdi_id` = `pcl`.`pdi_id`)))
        LEFT JOIN `golddisk` `v` ON ((`v`.`pdi_id` = `pcl`.`pdi_id`)))
        LEFT JOIN `pdi_catalog` `pdi` ON ((`pdi`.`id` = `pcl`.`pdi_id`)))
    GROUP BY `chk`.`id` , `s`.`stig_id` , `tgt`.`name`
    ORDER BY `s`.`stig_id` , FIELD(`chk`.`type`,
            'manual',
            'iavm',
            'policy',
            'benchmark');
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `get_orphan_findings`
--

DROP VIEW IF EXISTS `get_orphan_findings`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_orphan_findings` AS
    SELECT 
        `chk`.`id` AS `chk_id`,
        `chk`.`icon` AS `chk_icon`,
        `chk`.`type` AS `chk_type`,
        `s`.`stig_id` AS `stig_id`,
        `pcl`.`check_contents` AS `check_contents`,
        `v`.`vms_id` AS `vms_id`,
        `pdi`.`short_title` AS `short_title`,
        `tgt`.`id` AS `tgt_id`,
        `tgt`.`name` AS `tgt_name`,
        `tgt`.`cat_id` AS `cat_id`,
        IF(ISNULL(`f`.`findings_status_id`),
            'Not Reviewed',
            `fs`.`status`) AS `finding_status`,
        `pdi`.`id` AS `pdi_id`,
        `f`.`notes` AS `notes`,
        `f`.`cat` AS `finding_cat`,
        `pdi`.`cat` AS `cat`,
        (SELECT 
                GROUP_CONCAT(`fc`.`ia_control`
                        SEPARATOR ' ')
            FROM
                `finding_controls` `fc`
            WHERE
                (`fc`.`finding_id` = `f`.`id`)) AS `finding_ia_controls`,
        (SELECT 
                GROUP_CONCAT(DISTINCT CONCAT(`ia`.`type`, '-', `ia`.`type_id`)
                        SEPARATOR ' ')
            FROM
                `ia_controls` `ia`
            WHERE
                (`ia`.`pdi_id` = `pcl`.`pdi_id`)) AS `ia_controls`
    FROM
        (((((((`checklist` `chk`
        LEFT JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `chk`.`id`)))
        LEFT JOIN `findings` `f` ON ((`f`.`pdi_id` = `pcl`.`pdi_id`)))
        JOIN `target` `tgt` ON ((`tgt`.`id` = `f`.`tgt_id`)))
        LEFT JOIN `findings_status` `fs` ON ((`fs`.`id` = `f`.`findings_status_id`)))
        LEFT JOIN `stigs` `s` ON ((`s`.`pdi_id` = `pcl`.`pdi_id`)))
        LEFT JOIN `golddisk` `v` ON ((`v`.`pdi_id` = `pcl`.`pdi_id`)))
        LEFT JOIN `pdi_catalog` `pdi` ON ((`pdi`.`id` = `pcl`.`pdi_id`)))
    WHERE
        (NOT (`chk`.`id` IN (SELECT 
                `tc`.`chk_id`
            FROM
                `target_checklist` `tc`
            WHERE
                (`tc`.`tgt_id` = `tgt`.`id`))))
    GROUP BY `s`.`stig_id` , `tgt`.`name`
    ORDER BY `s`.`stig_id`;
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

DELIMITER $$
CREATE DEFINER=`web`@`{host}` FUNCTION `GET_CATEGORY_ID`() RETURNS int(11)
BEGIN
RETURN @category_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`web`@`{host}` FUNCTION `GET_TARGET_ID`() RETURNS int(11)
BEGIN
RETURN @target_id;
END$$
DELIMITER ;

--
-- Final view structure for view `get_cat_pdi_count`
--

DROP VIEW IF EXISTS `get_cat_pdi_count`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_cat_pdi_count` AS
    SELECT 
        `t`.`id` AS `id`,
        `t`.`name` AS `name`,
        `t`.`cat_id` AS `cat_id`,
        COUNT(DISTINCT `pcl`.`pdi_id`) AS `pdi_count`
    FROM
        (((`target` `t`
        JOIN `target_checklist` `tc` ON ((`tc`.`tgt_id` = `t`.`id`)))
        JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `tc`.`chk_id`)))
        LEFT JOIN `findings` `f` ON (((`f`.`pdi_id` = `pcl`.`pdi_id`)
            AND (`t`.`id` = `f`.`tgt_id`))))
    WHERE
        (`t`.`cat_id` = GET_CATEGORY_ID())
    GROUP BY `t`.`id`;
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `get_target_pdi_count`
--

DROP VIEW IF EXISTS `get_target_pdi_count`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_target_pdi_count` AS
    SELECT 
        `t`.`id` AS `id`,
        `t`.`name` AS `name`,
        `t`.`cat_id` AS `cat_id`,
        COUNT(DISTINCT `pcl`.`pdi_id`) AS `pdi_count`
    FROM
        (((`target` `t`
        JOIN `target_checklist` `tc` ON ((`tc`.`tgt_id` = `t`.`id`)))
        JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `tc`.`chk_id`)))
        LEFT JOIN `findings` `f` ON (((`f`.`pdi_id` = `pcl`.`pdi_id`)
            AND (`t`.`id` = `f`.`tgt_id`))))
    WHERE
        (`t`.`id` = GET_TARGET_ID())
    GROUP BY `t`.`id`;
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `target_view`
--

DROP VIEW IF EXISTS `target_view`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `target_view` AS
    (SELECT 
        `t`.`ste_id` AS `ste_id`,
        `cat`.`name` AS `cat_name`,
        `t`.`id` AS `id`,
        `t`.`name` AS `name`,
        `sw`.`sw_string` AS `os`,
        `t`.`location` AS `location`,
        `t`.`notes` AS `notes`,
        (SELECT 
                `task_status`.`status`
            FROM
                `task_status`
            WHERE
                (`task_status`.`id` = `t`.`auto_status_id`)) AS `auto_status`,
        (SELECT 
                `task_status`.`status`
            FROM
                `task_status`
            WHERE
                (`task_status`.`id` = `t`.`man_status_id`)) AS `man_status`,
        (SELECT 
                `task_status`.`status`
            FROM
                `task_status`
            WHERE
                (`task_status`.`id` = `t`.`data_status_id`)) AS `data_status`,
        (SELECT 
                `task_status`.`status`
            FROM
                `task_status`
            WHERE
                (`task_status`.`id` = `t`.`fp_cat1_status_id`)) AS `fp_cat1_status`
    FROM
        ((`target` `t`
        LEFT JOIN `software` `sw` ON ((`t`.`os_id` = `sw`.`id`)))
        LEFT JOIN `ste_cat` `cat` ON ((`t`.`cat_id` = `cat`.`id`))));
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `get_cat_finding_count`
--

DROP VIEW IF EXISTS `get_cat_finding_count`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_cat_finding_count` AS
    SELECT 
        `t`.`id` AS `id`,
        `t`.`name` AS `name`,
        `t`.`cat_id` AS `cat_id`,
        `f`.`cat` AS `severity`,
        IF(ISNULL(`fs`.`status`),
            'Not Reviewed',
            `fs`.`status`) AS `status`,
        COUNT(DISTINCT `f`.`pdi_id`) AS `finding_count`
    FROM
        ((((`target` `t`
        JOIN `target_checklist` `tc` ON ((`tc`.`tgt_id` = `t`.`id`)))
        JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `tc`.`chk_id`)))
        LEFT JOIN `findings` `f` ON (((`f`.`tgt_id` = `t`.`id`)
            AND (`pcl`.`pdi_id` = `f`.`pdi_id`))))
        LEFT JOIN `findings_status` `fs` ON ((`fs`.`id` = `f`.`findings_status_id`)))
    WHERE
        (`t`.`cat_id` = GET_CATEGORY_ID())
    GROUP BY `t`.`id` , `severity` , `f`.`findings_status_id`;
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `get_target_finding_count`
--

DROP VIEW IF EXISTS `get_target_finding_count`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `get_target_finding_count` AS
    SELECT 
        `t`.`id` AS `id`,
        `t`.`name` AS `name`,
        `t`.`cat_id` AS `cat_id`,
        `f`.`cat` AS `severity`,
        IF(ISNULL(`fs`.`status`),
            'Not Reviewed',
            `fs`.`status`) AS `status`,
        COUNT(DISTINCT `f`.`pdi_id`) AS `finding_count`
    FROM
        ((((`target` `t`
        JOIN `target_checklist` `tc` ON ((`tc`.`tgt_id` = `t`.`id`)))
        JOIN `pdi_checklist_lookup` `pcl` ON ((`pcl`.`checklist_id` = `tc`.`chk_id`)))
        LEFT JOIN `findings` `f` ON (((`f`.`tgt_id` = `t`.`id`)
            AND (`pcl`.`pdi_id` = `f`.`pdi_id`))))
        LEFT JOIN `findings_status` `fs` ON ((`fs`.`id` = `f`.`findings_status_id`)))
    WHERE
        (`t`.`id` = GET_TARGET_ID())
    GROUP BY `t`.`id` , `severity` , `f`.`findings_status_id`;
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

--
-- Final view structure for view `pdi`
--

DROP VIEW IF EXISTS `pdi`;
SET @saved_cs_client          = @@character_set_client;
SET @saved_cs_results         = @@character_set_results;
SET @saved_col_connection     = @@collation_connection;
SET character_set_client      = utf8;
SET character_set_results     = utf8;
SET collation_connection      = utf8_general_ci;
CREATE ALGORITHM=UNDEFINED
DEFINER=`web`@`{host}` SQL SECURITY DEFINER
VIEW `pdi` AS
    SELECT 
        `pdi`.`id` AS `pdi_id`,
        `s`.`stig_id` AS `STIG_ID`,
        `v`.`vms_id` AS `VMS_ID`,
        IF((`pdi`.`cat` = 1),
            'I',
            IF((`pdi`.`cat` = 2),
                'II',
                IF((`pdi`.`cat` = 3), 'III', ''))) AS `CAT`,
        (SELECT 
                GROUP_CONCAT(DISTINCT CONCAT(`ia`.`type`, '-', `ia`.`type_id`)
                        SEPARATOR ' ')
            FROM
                `ia_controls` `ia`
            WHERE
                (`ia`.`pdi_id` = `pdi`.`id`)) AS `IA_Controls`,
        '' AS `Notes`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `sv`.`sv_rule`
                        SEPARATOR ' ')
            FROM
                `sv_rule` `sv`
            WHERE
                (`sv`.`pdi_id` = `pdi`.`id`)) AS `SCAP_Rule`,
        `n`.`nessus_id` AS `Nessus_ID`
    FROM
        (((`pdi_catalog` `pdi`
        LEFT JOIN `stigs` `s` ON ((`s`.`pdi_id` = `pdi`.`id`)))
        LEFT JOIN `nessus` `n` ON ((`n`.`pdi_id` = `pdi`.`id`)))
        LEFT JOIN `golddisk` `v` ON ((`v`.`pdi_id` = `pdi`.`id`)));
SET character_set_client      = @saved_cs_client;
SET character_set_results     = @saved_cs_results;
SET collation_connection      = @saved_col_connection;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION;
SET SQL_NOTES=@OLD_SQL_NOTES;

-- Dump completed
