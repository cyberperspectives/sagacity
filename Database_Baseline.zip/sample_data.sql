CREATE DATABASE  IF NOT EXISTS `sagacity` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sagacity`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: localhost    Database: sagacity
-- ------------------------------------------------------
-- Server version	5.6.21-log

--
-- Loading sample data to system, sites, and ste tables
--

INSERT IGNORE INTO `system` (`name`,`abbr`,`mac`,`classification`,`acred_type`,`mitigations`,`description`,`executive_summary`) VALUES ('Test System','Test','3','Unclass','diacap','This is a list of mitigations suggested for the system','This is sample test system to demo the system','This executive summary is a short explanation of the overall vulnerability of the system that will be output in the final report');
SET @system_id=LAST_INSERT_ID();

INSERT INTO `sagacity`.`sites` (`name`,`address`,`city`,`state`,`zip`,`country`,`poc_name`,`poc_email`,`poc_phone`) VALUES ('Test Site', '123 Main St', 'Anytown', 'NY', 12345, 'US',  'John Doe', 'john@example.com', '123-456-7890');
SET @site_id=LAST_INSERT_ID();

INSERT IGNORE INTO `ste` (`system_id`,`site_id`,`eval_start`,`eval_end`,`multiple`,`primary`,`scope`,`ao`,`assumptions`,`constraints`,`recommendations`,`residual_risk`,`risk_status`,`deviations`,`conclusion`) VALUES (@system_id,@site_id,'2017-06-01 00:00:00','2017-06-01 23:59:59',0,0,'This is an explanation of the scope of this ST&E','You','This is a list of the assumptions made for this ST&E','This is a list of the constraints expected while testing','This is a list of the overall recommendations that the security engineers recommend to the system owner','This is the risk of the system','low','This is a list of deviations that were encountered while testing','This is the otherall conclusion about the state of system security after testing');
SET @ste_id=LAST_INSERT_ID();

-- Load complete
