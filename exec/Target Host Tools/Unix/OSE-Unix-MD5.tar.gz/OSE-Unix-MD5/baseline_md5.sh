#!/usr/bin/sh
VERSION="1.0, 1 Sep 09"
DATE=`date '+%m%d%y-%H%M%S'`
HOSTNAME=`hostname`
CRITFILE="./verifyfiles.txt"
OUTDIR="$HOSTNAME-verify/"
OUTFILE="$HOSTNAME-verify/$HOSTNAME-$DATE-verify.txt"
mkdir -p $OUTDIR
echo "Version: baseline_md5.sh $VERSION" | tee -a $OUTFILE

for file in `cat $CRITFILE` ; do
	./md5-sparc $file | tee -a $OUTFILE
done

./md5-sparc $OUTFILE | tee -a $OUTDIR/$HOSTNAME-verify.txt
